package com.microservices.auth.dto;

public record UserProfileDto(
        String name,
        String email
) {}
