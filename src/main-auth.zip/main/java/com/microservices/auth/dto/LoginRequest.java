package com.microservices.auth.dto;


public record LoginRequest(String email, String password){}
